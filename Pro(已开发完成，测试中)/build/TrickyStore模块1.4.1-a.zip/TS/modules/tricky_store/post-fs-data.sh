MODDIR=${0%/*}
